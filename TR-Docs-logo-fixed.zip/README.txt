TR Docs logo fix

This package contains index.html with the logo embedded directly as a data URI, so the header logo and favicon do not depend on a separate image file path.

To apply: replace the repository root index.html with this index.html and commit the change. The other PDF tools are preserved from the supplied TR Docs website package.
